// This file contains the JavaScript code for the personal web profile.
// It may include functionality such as event handling and dynamic content updates.

document.addEventListener('DOMContentLoaded', () => {
    const greetingElement = document.getElementById('greeting');
    const currentDate = new Date();
    const hours = currentDate.getHours();
    
    let greetingMessage;

    if (hours < 12) {
        greetingMessage = 'Good Morning!';
    } else if (hours < 18) {
        greetingMessage = 'Good Afternoon!';
    } else {
        greetingMessage = 'Good Evening!';
    }

    greetingElement.textContent = greetingMessage;

    // Additional functionality can be added here
});